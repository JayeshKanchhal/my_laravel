<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php if(session('response')): ?>
                    <div class="alert alert-success"><?php echo e(session('response')); ?></div>
            <?php endif; ?>
            <div class="panel panel-default text-center">
                <div class="panel-heading ">Post View</div>

                <div class="panel-body">
                    <div classs="col-md-4">
                        
                        
                    </div> 
                    <div classs="col-md-8">
                        <?php if(count($posts) > 0): ?>
                            <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4><?php echo e($post->post_title); ?></h4>
                                <img src="<?php echo e($post->post_pic); ?>" alt = "">
                                <p><?php echo e($post->post_body); ?></p>
                                <ul class ="nav nav-pills">
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/view/{ $post->id }")); ?>'>
                                            <span class="fa fa-thumbs-up">Likes (<?php echo e($likeCnt); ?>)</span>
                                        </a>
                                    </li>
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/view/{ $post->id }")); ?>'>
                                            <span class="fa fa-thumbs-down">Dislikes (<?php echo e($dislikeCnt); ?>)</span>
                                        </a>
                                    </li>
                                    <li role="presentation">
                                        <a href='<?php echo e(url("/view/{ $post->id }")); ?>'>
                                            <span class="fa fa-comment">Comment</span>
                                        </a>
                                    </li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No Post Available </p>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e('url(/comment/{$post->id})'); ?>">
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <textarea id ="comment" rows="6" class ="from-control" name="comment" required autofocus>
                                    </textarea>
                                </div>
                                <div class="from-group">
                                    <button type="submit" class="btn btn-success btn-lg">POST COMMENT</button>

                                </div>
                        </form>
                    </div>      
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>