@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            @if(session('response'))
                    <div class="alert alert-success">{{session('response')}}</div>
            @endif
            <div class="panel panel-default text-center">
                <div class="panel-heading ">Post View</div>

                <div class="panel-body">
                    <div classs="col-md-4">
                        
                        
                    </div> 
                    <div classs="col-md-8">
                        @if(count($posts) > 0)
                            @foreach($posts->all() as $post)
                                <h4>{{ $post->post_title }}</h4>
                                <img src="{{ $post->post_pic }}" alt = "">
                                <p>{{ $post->post_body }}</p>
                                <ul class ="nav nav-pills">
                                    <li role="presentation">
                                        <a href='{{url("/view/{ $post->id }")}}'>
                                            <span class="fa fa-thumbs-up">Likes ({{ $likeCnt }})</span>
                                        </a>
                                    </li>
                                    <li role="presentation">
                                        <a href='{{url("/view/{ $post->id }")}}'>
                                            <span class="fa fa-thumbs-down">Dislikes ({{ $dislikeCnt }})</span>
                                        </a>
                                    </li>
                                    <li role="presentation">
                                        <a href='{{url("/view/{ $post->id }")}}'>
                                            <span class="fa fa-comment">Comment</span>
                                        </a>
                                    </li>
                                </ul>
                            @endforeach
                        @else
                            <p>No Post Available </p>
                        @endif

                        <form method="POST" action="{{ 'url(/comment/{$post->id})' }}">
                            {{ csrf_field() }}
                                <div class="form-group">
                                    <textarea id ="comment" rows="6" class ="from-control" name="comment" required autofocus>
                                    </textarea>
                                </div>
                                <div class="from-group">
                                    <button type="submit" class="btn btn-success btn-lg">POST COMMENT</button>

                                </div>
                        </form>
                    </div>      
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
