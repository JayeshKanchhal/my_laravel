<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Post;
use App\Like;
use App\Dislike;
use App\Comment;
use Auth;

class PostController extends Controller
{
    public function post()
    {

    	return view('posts.post');
    }
    public function addPost(Request $request)
    {
    	$this->validate($request, [
    		'post_title'=>'required',
    		'post_body'=>'required',
    		'post_pic'=>'required',
    	]);
    	$post = new Post;
    	$post->post_title = $request->input('post_title');
    	$post->user_id = Auth::user()->id;
    	$post->post_body = $request->input('post_body');
    	if(Input::hasFile('post_pic'))
    	{
    		$file = Input::file('post_pic');
   $file->move(public_path().'/posts/',
    			$file->getClientOriginalName());
    		$url = URL::to("/").'/posts/'.
    			$file->getClientOriginalName();
    	}
    	$post->post_pic = $url;
    	$post->save();
    	return redirect('/home')->with('response','Post Added Successfully');
    }
    public function view($post_id)
    {
    	$posts = Post::where('id', '=', $post_id)->get();
		$likePost = Post::find($post_id);
    	$likeCnt = Like::where(['post_id' => $likePost->id])->count();
    	$dislikeCnt = Dislike::where(['post_id' => $likePost->id])->count();
    	return view('posts.view',['posts' => $posts,'likeCnt' => $likeCnt, 'dislikeCnt' => $dislikeCnt]);
    	}
    }
    public function like($id)
   	{
    	$loggedin_user = Auth::user()->id;
    	$like_user = Like::where(['user_id' => $loggedin_user, 'post_id' => $id])->first();
    	if (empty($like_user->user_id)) {
    		$user_id = Auth::user()->id;
    		$email = Auth::user()->email;
    		$post_id = $id;
    		$like = new Like;
    		$like->user_id = $user_id;
    		$like->email = $email;
    		$like->post_id = $post_id;
    		$like->save();
    		return redirect("/view/{$id}");
    	}
    	else{
    		return redirect("/view/{$id}");
    	}

	 }

	public function dislike($id)
   	{
    	$loggedin_user = Auth::user()->id;
    	$dislike_user = Dislike::where(['user_id' => $loggedin_user, 'post_id' => $id])->first();
    	if (empty($like_user->user_id)) {
    		$user_id = Auth::user()->id;
    		$email = Auth::user()->email;
    		$post_id = $id;
    		$dislike = new Dislike;
    		$dislike->user_id = $user_id;
    		$dislike->email = $email;
    		$dislike->post_id = $post_id;
    		$dislike->save();
    		return redirect("/view/{$id}");
    	}
    	else{
    		return redirect("/view/{$id}");
    	}
	}

	public function comment(Request $request, $post_id)
   	{
   		$this->validate($request, [
    		'comment'=>'required'
    	]);
    	$comment = new Comment;
    	$comment->user_id = Auth::user()->id;
    	$comment->user_id = $post_id;
    	$comment->comment = $request->input('comment');
    	$comment->save();
    	return redirect("/view/{$post_id}")->with('response','Comment Added Successfully');
   	}
}